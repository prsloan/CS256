#pragma once
class Polynomial
{
public:
	Polynomial();
	Polynomial(int);
	Polynomial(const Polynomial&);
	void set(int, int);
	void print(void);
	Polynomial operator+(const Polynomial&);
	Polynomial operator-(const Polynomial&);
	Polynomial operator*(const Polynomial&);
	Polynomial operator=(const Polynomial&);
	~Polynomial();


private:
	int *coEfficients;
	int highestPower;


};

