#include "Polynomial.h"
#include <iostream>


Polynomial::Polynomial()
{
	coEfficients = new int[50];
	highestPower = 50;
	for (int i = 0; i < 50; i++)
		coEfficients[i] = 0;
}

Polynomial::Polynomial(int maxPower){
		coEfficients = new int[maxPower+1];
		highestPower = maxPower;
		for (int i = 0; i < maxPower+1; i++)
			coEfficients[i] = 0;
}

Polynomial::Polynomial(const Polynomial &oldPoly){
	coEfficients = new int[oldPoly.highestPower+1];
	for (int i = 0; i <= oldPoly.highestPower;i++)
		coEfficients[i] = oldPoly.coEfficients[i];
	highestPower = oldPoly.highestPower;
}


void Polynomial::set(int coEf, int power){
	if (power > highestPower)
		std::cout << "This power is too high for this polynomial.\n";
	else
		coEfficients[power] = coEf;
		


}
void Polynomial::print(void){
	bool first = true;
	for (int i = 0; i <= highestPower; i++){
		if (coEfficients[i]>0 && !first)
			std::cout << " + " << coEfficients[i] << "x^" << i;
		else if (coEfficients[i]<0)
			std::cout << " - " << -coEfficients[i] << "x^" << i;
		else if (coEfficients[i]>0 && first){
			std::cout << coEfficients[i] << "x^" << i;
			first = false;
			}
	}

}

Polynomial Polynomial::operator+(const Polynomial& other) {
	Polynomial temp;
	temp = (highestPower > other.highestPower) ? Polynomial(highestPower) : Polynomial(other.highestPower);
	
	for (int i = 0; i <= temp.highestPower; i++){
		if (i > other.highestPower)
			temp.coEfficients[i] = coEfficients[i];
		else if (i > highestPower)
			temp.coEfficients[i] = other.coEfficients[i];
		else
			temp.coEfficients[i] = coEfficients[i] + other.coEfficients[i];
	}
	return temp;

}
Polynomial Polynomial::operator-(const Polynomial& other){
	Polynomial temp;
	temp = (highestPower > other.highestPower) ? Polynomial(highestPower) : Polynomial(other.highestPower);

	for (int i = 0; i <= temp.highestPower; i++){
		if (i > other.highestPower)
			temp.coEfficients[i] = coEfficients[i];
		else if (i > highestPower)
			temp.coEfficients[i] -= other.coEfficients[i];
		else
			temp.coEfficients[i] = coEfficients[i] - other.coEfficients[i];
	}

	return temp;
}
Polynomial Polynomial::operator*(const Polynomial& other){
	Polynomial temp;
	temp = Polynomial(highestPower*other.highestPower);

	for (int i = 0; i <= highestPower; i++)
		for (int j = 0; j<= other.highestPower;j++) 
		temp.coEfficients[i+j] += coEfficients[i]*other.coEfficients[j];

		
		return temp;
}
Polynomial Polynomial::operator=(const Polynomial& other){
	//delete [] coEfficients;
	coEfficients = new int[other.highestPower + 1];
	highestPower = other.highestPower;
	for (int i = 0; i <= highestPower; i++)
		coEfficients[i] = other.coEfficients[i];

	return *this;

}

Polynomial::~Polynomial()
{
	delete  coEfficients;
}
