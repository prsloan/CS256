// Project3-1.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include "Polynomial.h"



using namespace std;

int menu(void);









int main()
{

	int pInput, cInput;
	int power1, power2;
	int terms1, terms2;
	int menuChoice = 0;
	int assignChoice = 0;
	Polynomial poly3;
	

	cout << "Welcome to the polynoiator. Answer the prompts to enter data for the 2 polynomials!\n " << endl;
	cout << "How many terms will be in the first Polynomial : ";
	cin >> terms1;
	cout << "What is the highest power of the first Polynomial :";
	cin >> power1;
	Polynomial poly1 = Polynomial(power1);

	for (int i = 0; i < terms1; i++){
		cout << "\nEnter the Coefficient for term "<< i+1<<": ";
		cin >> cInput;
		cout << "\nEnter the power for term " << i + 1 << ": ";
		cin >> pInput;
		poly1.set(cInput, pInput);
	}

	poly1.print();

	cout << "\n\nHow many terms will be in the second Polynomial : ";
	cin >> terms2;
	cout << "What is the highest power of the second Polynomial :";
	cin >> power2;
	Polynomial poly2 = Polynomial(power2);

	for (int i = 0; i < terms2; i++){
		cout << "\nEnter the Coefficient for term " << i + 1 << ": ";
		cin >> cInput;
		cout << "\nEnter the power for term " << i + 1 << ": ";
		cin >> pInput;
		poly2.set(cInput, pInput);
	}

	poly2.print();

	while (menuChoice != 6){
		menuChoice = menu();

		switch (menuChoice){
			case 1:
				poly3 = (power1 > power2) ? Polynomial(power1) : Polynomial(power2);
				poly3 = poly1 + poly2;
				cout << "(";
				poly1.print();
				cout << ") + (";
				poly2.print();
				cout << ") = ";
				poly3.print();
				cout << "\n\n";
				break;
			case 2:
				poly3 = (power1 > power2) ? Polynomial(power1) : Polynomial(power2);
				poly3 = poly2 - poly1;
				cout << "(";
				poly2.print();
				cout << ") - (";
				poly1.print();
				cout << ") = ";
				poly3.print();
				cout << "\n\n";
				break;
			case 3:
				poly3 = (power1 > power2) ? Polynomial(power1) : Polynomial(power2);
				poly3 = poly1 - poly2;
				cout << "(";
				poly1.print();
				cout << ") - (";
				poly2.print();
				cout << ") = ";
				cout << "\n\n";
				poly3.print();
				break;
			case 4:
				cout << "\nChose: (1)Assign first to second or (2) assign second to first :";
				cin >> assignChoice;
				if (assignChoice == 1)
					poly2 = poly1;
				if (assignChoice == 2)
					poly1 = poly2;
				cout << "\n First :";
				poly1.print();
				cout << "\n Second :";
				poly2.print();
				break;
			case 5:
				poly3 = Polynomial(power1*power2);
				poly3 = poly2*poly1;
				cout << "(";
				poly2.print();
				cout << ") * (";
				poly1.print();
				cout << ") = ";
				poly3.print();
				cout << "\n\n";
				break;
		}

	}



	system("pause");
	return 0;
}

int menu(){
	int choice;

	cout << "\n\nChose from the following options : " << endl;
	cout << "1. Add the Polynomials" << endl;
	cout << "2. Subtract first polynomial from second." << endl;
	cout << "3. Subtract second polynomial from first." << endl;
	cout << "4. Assign a polynomial." << endl;
	cout << "5. Multiply the polynomials" << endl;
	cout << "6. Exit" << endl;
	cout << "Enter Your Choice: ";
	cin >> choice;
	return choice;
}